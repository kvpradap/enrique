class Matcher(object):
    pass