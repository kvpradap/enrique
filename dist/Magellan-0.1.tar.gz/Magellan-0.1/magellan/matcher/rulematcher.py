from magellan.matcher.matcher import Matcher

class RuleMatcher(Matcher):
    pass


