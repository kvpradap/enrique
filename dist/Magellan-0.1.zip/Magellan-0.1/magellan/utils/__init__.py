# install path
import os

installpath = os.path.dirname(os.path.realpath(__file__))