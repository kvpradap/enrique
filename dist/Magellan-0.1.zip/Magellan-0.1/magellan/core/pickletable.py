class PickleTable(object):
    def __init__(self, table, properties):
        self.table = table
        self.properties = properties
