class Matcher(object):
    pass