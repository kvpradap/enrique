Magellan
--------

To use Magellan, simply do::

    >>> import magellan as mg

and start executing magellan commands